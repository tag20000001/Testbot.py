python-opus
===========

Python bindings to the libopus, IETF low-delay audio codec

Testing
--------

Run tests with a python setup.py test command or look for [Travis build logs](http://travis-ci.org/#!/svartalf/python-opus).

![](https://secure.travis-ci.org/svartalf/python-opus.png)

Contributing
-------------

If you want to contribute, follow the [pep8](http://www.python.org/dev/peps/pep-0008/) guideline, and include the tests.
